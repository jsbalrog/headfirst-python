from setuptools import setup

setup(
    name="vsearch",
    version="1.0",
    description="Search Tools",
    author="Ted Jenkins",
    author_email="edtjen@gmail.com",
    url="",
    py_modules=["vsearch"],
)
